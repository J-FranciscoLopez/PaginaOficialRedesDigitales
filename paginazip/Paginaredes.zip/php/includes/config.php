<?php
session_start();
$databaseURL = "https://paginaredes-39e74-default-rtdb.firebaseio.com/";