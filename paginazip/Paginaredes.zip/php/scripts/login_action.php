<?php
include("../includes/config.php");
include("../includes/firebaseRDB.php");


$email = $_POST['email'];
$password = $_POST['password'];

if(empty($email)){
  echo "Por favor ingresar un correo electrónico ";
  echo "<a href='../../login.php'>volver a intentar</a>";
} else if(empty($password)){
  echo "Por favor ingresar una contraseña ";
  echo "<a href='../../login.php'>volver a intentar</a>";
} else {
  $rdb = new firebaseRDB($databaseURL);
  $retrieve = $rdb->retrieve("/user", "email", "EQUAL", $email);
  $data = json_decode($retrieve, 1);

  if(count($data) == 0){
    echo "La cuenta no existe ";
    echo "<a href='../../signup.php'>Crear una cuenta</a>";
  } else {
    $userKey = array_keys($data)[0]; // Obtiene la primera clave del arreglo de datos, que corresponde al ID del usuario
    $user = $data[$userKey]; // Accede a los datos del usuario
    if(password_verify($password, $user['password'])){
      // Si la verificación es exitosa, almacenar los datos del usuario en sesión
      $_SESSION['user'] = $user;
      header("Location: ../../dashboard.php"); // Redirige al dashboard si el login es exitoso
      exit;
    } else {
      echo "Acceso fallido, contraseña incorrecta ";
      echo "<a href='../../login.php'>volver a intentar</a>";
    }
  }
}
?>
