<?php
include("../includes/config.php");
include("../includes/firebaseRDB.php");

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

$errors = [];

if (empty($name) || !preg_match("/^[a-zA-Z0-9]+$/", $name)) {
    $errors['name'] = "Por favor ingresar un nombre válido (solo letras y números).";
}

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = "Por favor ingresar un correo electrónico válido.";
}

if (empty($password) || !preg_match("/^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/", $password)) {
    $errors['password'] = "La contraseña debe tener al menos 8 caracteres, incluir al menos un número, una mayuscula, una minuscula y un símbolo.";
}

if (!empty($errors)) {
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
    echo "<a href='../../signup.php'>Volver a intentar</a>";
} else {
    $rdb = new firebaseRDB($databaseURL);
    $retrieve = $rdb->retrieve("/user", "email", "EQUAL", $email);
    $data = json_decode($retrieve, 1);

    if(count($data) > 0){
        echo "La cuenta ya existe ";
        echo "<a href='../../signup.php'>Ir a inicio de sesión</a>";
    }else{
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);  // Seguridad: Hash de la contraseña
        $insert = $rdb->insert("/user", [
            "name" => $name,
            "email" => $email,
            "password" => $hashedPassword
        ]);
        $result = json_decode($insert, 1);
        if(isset($result['name'])){
            echo "Registro exitoso por favor inicie sesión ";
            echo "<a href='../../login.php'>Ir a inicio de sesión</a>";
        }else{
            echo "Registro fallido ";
            echo "<a href='../../signup.php'>Volver a intentar</a>";
        }
    }
}
?>
