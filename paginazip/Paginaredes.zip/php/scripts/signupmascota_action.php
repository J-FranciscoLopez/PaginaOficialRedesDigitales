<?php
include("../includes/config.php");
include("../includes/firebaseRDB.php");
  
$nombre = $_POST['nombre'];
$edad = $_POST['edad'];
$raza = $_POST['raza'];
$padecimientos = $_POST['padecimientos'];
$tipodesangre = $_POST['tipodesangre'];
$direcciondueno = $_POST['direcciondueno'];
$numerocontacto = $_POST['numerocontacto'];
$vacunas = $_POST['vacunas'];
$cirugias = $_POST['cirugias'];
$veterinariocabecera = $_POST['veterinariocabecera'];
$informacionadicional = $_POST['informacionadicional'];
$emaildueno = $_SESSION['user']['email'];

if($nombre == ""){
  echo "El nombre de la mascota es requerido ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($edad == ""){
  echo "La edad de la mascota es requerida ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($raza == ""){
  echo "La raza de la mascota es requerida ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($padecimientos == ""){
  echo "Los padecimientos de la mascota son requeridos ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($tipodesangre == ""){
  echo "El tipo de sangre de la mascota es requerido ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($direcciondueno == ""){
  echo "La direccion del dueño de la mascota es requerida ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($numerocontacto == ""){
  echo "El numero de contacto del dueño es requerido ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($vacunas == ""){
  echo "Las vacunas de la mascota son requeridas ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($cirugias == ""){
  echo "Las cirugias de la mascota son requeridas ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($veterinariocabecera == ""){
  echo "El veterinario de la cabecera de la mascota es requerido ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else if($informacionadicional == ""){
  echo "La informacion adicional de la mascota es requerida ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
}else{
  $rdb = new firebaseRDB($databaseURL);
  $retrieve = $rdb->retrieve("/mascota", "nombre", "EQUAL", $nombre);
  $data = json_decode($retrieve, 1);

  $insert = $rdb->insert("/mascota", [
                          "emaildueno" => $emaildueno,
                          "nombre" => $nombre,
                          "edad" => $edad,
                          "raza" => $raza,
                          "padecimientos" => $padecimientos,
                          "tipodesangre" => $tipodesangre,
                          "direcciondueno" => $direcciondueno,
                          "numerocontacto" => $numerocontacto,
                          "vacunas" => $vacunas,
                          "cirugias" => $cirugias,
                          "veterinariocabecera" => $veterinariocabecera,
                          "informacionadicional" => $informacionadicional
                        ]);
  $result = json_decode($insert, 1);
  
  if(isset($result['name'])){
    echo "Registro de informacion exitoso ";
    echo "<a href='../../dashboard.php'>Volver a Dashboard</a>";
  }else{
    echo "Registro de informacion fallido ";
    echo "<a href='../../dashboard.php'>Volver a Dashboard</a>";
  }
}