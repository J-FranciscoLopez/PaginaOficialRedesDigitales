<?php

include("../includes/config.php");
include("../includes/firebaseRDB.php");

if (!isset($_SESSION['user'])) {
    header("location: ../../login.php");
    exit;
}

$emaildueno = $_SESSION['user']['email'];


$nombre = $_POST['nombre'] ?? '';
$edad = $_POST['edad'] ?? '';
$raza = $_POST['raza'] ?? '';
$padecimientos = $_POST['padecimientos'] ?? '';
$tipodesangre = $_POST['tipodesangre'] ?? '';
$direcciondueno = $_POST['direcciondueno'] ?? '';
$numerocontacto = $_POST['numerocontacto'] ?? '';
$vacunas = $_POST['vacunas'] ?? '';
$cirugias = $_POST['cirugias'] ?? '';
$veterinariocabecera = $_POST['veterinariocabecera'] ?? '';
$informacionadicional = $_POST['informacionadicional'] ?? '';

$requiredFields = [$nombre, $edad, $raza, $padecimientos, $tipodesangre, $direcciondueno, $numerocontacto, $vacunas, $cirugias, $veterinariocabecera, $informacionadicional];
$missingFields = array_filter($requiredFields, function ($value) { return $value === ''; });


if (count($missingFields) > 0) {
    echo "Todos los campos son requeridos. ";
    echo "<a href='../../signupmascota.php'>Reintentar</a>";
    exit;
}

$rdb = new firebaseRDB($databaseURL);

$retrieve = $rdb->retrieve("/mascota", "emaildueno", "EQUAL", $emaildueno);
$data = json_decode($retrieve, true);

if (empty($data)) {
    $insert = $rdb->insert("/mascota", [
                               "emaildueno" => $emaildueno,
                               "nombre" => $nombre,
                               "edad" => $edad,
                               "raza" => $raza,
                               "padecimientos" => $padecimientos,
                               "tipodesangre" => $tipodesangre,
                               "direcciondueno" => $direcciondueno,
                               "numerocontacto" => $numerocontacto,
                               "vacunas" => $vacunas,
                               "cirugias" => $cirugias,
                               "veterinariocabecera" => $veterinariocabecera,
                               "informacionadicional" => $informacionadicional,
                           ]);
    $result = json_decode($insert, true);

    if (isset($result['name'])) {
        echo "Registro de informacion exitoso. ";
        echo "<a href='../../dashboard.php'>Volver a Dashboard</a>";
    } else {
        echo "Registro de informacion fallido. ";
        echo "<a href='../../signupmascota.php'>Reintentar</a>";
    }
} else {
    $id = array_keys($data)[0];
    $update = $rdb->update("/mascota", $id, [
                               "emaildueno" => $emaildueno,
                               "nombre" => $nombre,
                               "edad" => $edad,
                               "raza" => $raza,
                               "padecimientos" => $padecimientos,
                               "tipodesangre" => $tipodesangre,
                               "direcciondueno" => $direcciondueno,
                               "numerocontacto" => $numerocontacto,
                               "vacunas" => $vacunas,
                               "cirugias" => $cirugias,
                               "veterinariocabecera" => $veterinariocabecera,
                               "informacionadicional" => $informacionadicional,
                           ]);

    if ($update) {
        echo "Actualización exitosa. ";
        echo "<a href='../../dashboard.php'>Volver a Dashboard</a>";
  } else {
  echo "Actualización fallida. ";
  echo "<a href='../../signupmascota.php'>Reintentar</a>";
  }
}
?>
