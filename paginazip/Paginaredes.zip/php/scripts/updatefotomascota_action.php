<?php

include("../includes/config.php");
include("../includes/firebaseRDB.php");

if (!isset($_SESSION['user'])) {
    header("location: ../../login.php");
    exit;
}

$emaildueno = $_SESSION['user']['email'];

if (!empty($_FILES['fotoMascota']['name'])) {
    $targetDir = "../../uploads/perritos/";
    $fileType = strtolower(pathinfo($_FILES['fotoMascota']['name'], PATHINFO_EXTENSION));
    $nombreMascotaSanitizado = preg_replace("/[^a-zA-Z0-9]+/", "-", strtolower($emaildueno));
    $fileName = $nombreMascotaSanitizado . '.' . $fileType;
    $targetFilePath = $targetDir . $fileName;

    $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
    if (in_array($fileType, $allowTypes)) {
        // Eliminar archivos antiguos
        $files = glob($targetDir . $nombreMascotaSanitizado . '*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }

        // Subir archivo nuevo
        if (move_uploaded_file($_FILES['fotoMascota']['tmp_name'], $targetFilePath)) {
            echo 'La foto se ha subido correctamente.';
        } else {
            echo 'La subida de la foto ha fallado.';
            $targetFilePath = "../../uploads/perritos/perrito.jpg"; // Usar imagen por defecto en caso de fallo
        }
    } else {
        echo 'Solo se permiten archivos JPG, JPEG, PNG, & GIF.';
        $targetFilePath = "../../uploads/perritos/perrito.jpg"; // Usar imagen por defecto si el formato no es correcto
    }
} else {
    // No se subió ninguna foto, usar la imagen por defecto
    $targetFilePath = "../../uploads/perritos/perrito.jpg";
}




$rdb = new firebaseRDB($databaseURL);

$retrieve = $rdb->retrieve("/mascotafoto", "emaildueno", "EQUAL", $emaildueno);
$data = json_decode($retrieve, true);

if (empty($data)) {
    $insert = $rdb->insert("/mascotafoto", [
                           "emaildueno" => $emaildueno,
                           "fotoUrl" => $fileName  // Asegúrate de que esta URL sea accesible públicamente si es necesario
                           ]);
    $result = json_decode($insert, true);

    if (isset($result['name'])) {
        echo "Registro de informacion exitoso. ";
        echo "<a href='../../dashboard.php'>Volver a Dashboard</a>";
    } else {
        echo "Registro de informacion fallido. ";
        echo "<a href='../../dashboard.php'>Reintentar</a>";
    }
} else {
    $id = array_keys($data)[0];
    $update = $rdb->update("/mascotafoto", $id, [
                              "emaildueno" => $emaildueno,
                              "fotoUrl" => $fileName  // Asegúrate de que esta URL sea accesible públicamente si es necesario
                           ]);

    if ($update) {
        echo "Actualización exitosa. ";
        echo "<a href='../../dashboard.php'>Volver a Dashboard</a>";
  } else {
  echo "Actualización fallida. ";
  echo "<a href='../../dashboard.php'>Reintentar</a>";
  }
}
?>
