<?php
include("../includes/config.php");
include("../includes/firebaseRDB.php");

if(isset($_SESSION['user'])){
  unset($_SESSION['user']);
}

header("location: ../../index.php");