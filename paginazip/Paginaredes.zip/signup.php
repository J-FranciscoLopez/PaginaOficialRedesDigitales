<?php
include("./php/includes/config.php");

if(isset($_SESSION['user'])){
  header("location: dashboard.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" >
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrarse</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
</head>
  
<body>
  <div class="backgroundsignup white">
    <div class="background__overlay">
      <form method="post" action="./php/scripts/signup_action.php" class="formu2">
        <h2>Registrate</h2>
        <div class="formu__elementos">
          <div class="formu__elementos__input">
            <div class="input-group">
                <label for="name">Nombre</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="input-group">
                <label for="email">Correo electronico</label>
                <input type="text" id="email" name="email" required>
            </div>
            <div class="input-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required>
            </div>
          </div>
          <button type="submit" class="menu__button">Registrarse</button>
        </div>
        <p>¿Ya tienes una cuenta?</br><a href="login.php">Acceder</a></p>
      </form> 
    </div>
  </div>
</body>
</html>