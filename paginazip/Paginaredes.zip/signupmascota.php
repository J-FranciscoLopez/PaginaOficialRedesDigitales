<?php
include("./php/includes/config.php");
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" >
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrarse</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
</head>
  
<body>
  <div class="backgroundsignup white">
    <div class="background__overlay">
      <form method="post" action="./php/scripts/updatemascota_action.php" class="formu3">
        <h2>Registra a tu mascota</h2>
        <div class="formu__elementos">
          <div class="formu__elementos__input">
            <div class="input-group">
                <label for="nombre">Nombre</label>
                <input type="text" id="nombre" name="nombre" required>
            </div>
            <div class="input-group">
                <label for="edad">Edad</label>
                <input type="text" id="edad" name="edad" required>
            </div>
            <div class="input-group">
                <label for="raza">Raza</label>
                <input type="text" id="raza" name="raza" required>
            </div>
            <div class="input-group">
                <label for="padecimientos">Padecimientos</label>
                <input type="text" id="padecimientos" name="padecimientos" required>
            </div>
            <div class="input-group">
                <label for="tipodesangre">Tipo De Sangre</label>
                <input type="text" id="tipodesangre" name="tipodesangre" required>
            </div>
            <div class="input-group">
                <label for="direcciondueno">Direccion del dueño</label>
                <input type="text" id="direcciondueno" name="direcciondueno" required>
            </div>
            <div class="input-group">
                <label for="numerocontacto">Numero de contacto</label>
                <input type="text" id="numerocontacto" name="numerocontacto" required>
            </div>
            <div class="input-group">
                <label for="vacunas">Vacunas </label>
                <input type="text" id="vacunas" name="vacunas" required>
            </div>
            <div class="input-group">
                <label for="cirugias">Cirugias </label>
                <input type="text" id="cirugias" name="cirugias" required>
            </div>
            <div class="input-group">
                <label for="veterinariocabecera">Veterinario de cabecera</label>
                <input type="text" id="veterinariocabecera" name="veterinariocabecera" required>
            </div>
            <div class="input-group">
                <label for="informacionadicional">Informacion adicional</label>
                <input type="text" id="informacionadicional" name="informacionadicional" required>
            </div>
          </div>
          <button type="submit" class="menu__button">Registrar mascota</button>
        </div>
      </form> 
    </div>
  </div>
</body>
</html>