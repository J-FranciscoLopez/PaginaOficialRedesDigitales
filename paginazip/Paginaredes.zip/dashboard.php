<?php
include("./php/includes/config.php");
include("./php/includes/firebaseRDB.php");

if(!isset($_SESSION['user'])){
  header("location: login.php");
  exit;
}

$emailduenoperro = $_SESSION['user']['email'];

$rdb = new firebaseRDB($databaseURL);
$retrieve = $rdb->retrieve("/mascota", "emaildueno", "EQUAL", $emailduenoperro);
$data = json_decode($retrieve, 1);

if(count($data) == 0){
  header("location: signupmascota.php");
  exit;
}else {
  $id = array_keys($data)[0];
}

$retrieve2 = $rdb->retrieve("/mascotafoto", "emaildueno", "EQUAL", $emailduenoperro);
$data2 = json_decode($retrieve2, 1);

if(count($data2) == 0){
  header("location: signupfotomascota.php");
  exit;
}else {
  $id2 = array_keys($data2)[0];
}

if(!file_exists("datosservo2.txt")){
    file_put_contents("datosservo2.txt", "0\r\n");
}

// Maneja las solicitudes POST para cambiar el valor
if(isset($_POST['comederoval'])){
    $TEXTO = $_POST['comederoval'] . "\r\n";
    file_put_contents("datosservo2.txt", $TEXTO);
}

$ARCHIVO = file_get_contents("datosservo2.txt");
$pos = strpos($ARCHIVO, "\r\n");
$VAR1 = substr($ARCHIVO, 0, $pos);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
</head>

<body>
    <div class="backgrounddashboard">
        <div class="background__overlaydash">
          <div class="nav">
            <div class="nombrenav">
              <h1 class="titles__title titles__title--sub2">Bienvenido <?php echo $_SESSION['user']['name']; ?></h1>
            </div>
            <div class="botonesnav">
              <a href="signupfotomascota.php" class="menu__button">Cambiar foto</a>
              <a href="signupmascota.php" class="menu__button">Editar ficha mascota</a>
              <a href="./php/scripts/logout.php" class="menu__button">Cerrar sesion</a>
            </div>
          </div>
          <div class="fichaperro">
            <div class="fichaperroizq">
              <h2 class="nombremascota"><?php echo $data[$id]['nombre']; ?></h2>
              <img src="./uploads/perritos/<?php echo $data2[$id2]['fotoUrl']; ?>" class="fotomascota" alt="Imagen de mascota">
            </div>
            <div class="fichaperroder">
              <h2 class="fichamascota">Raza: <?php echo $data[$id]['raza']; ?></h2>
              <h2 class="fichamascota">Edad: <?php echo $data[$id]['edad']; ?></h2>
              <h2 class="fichamascota">Padecimientos: <?php echo $data[$id]['padecimientos']; ?></h2>
              <h2 class="fichamascota">Tipo de Sangre: <?php echo $data[$id]['tipodesangre']; ?></h2>
              <h2 class="fichamascota">Direccion del dueño: <?php echo $data[$id]['direcciondueno']; ?></h2>
              <h2 class="fichamascota">Numero de contacto: <?php echo $data[$id]['numerocontacto']; ?></h2>
              <h2 class="fichamascota">Vacunas: <?php echo $data[$id]['vacunas']; ?></h2>
              <h2 class="fichamascota">Cirugias: <?php echo $data[$id]['cirugias']; ?></h2>
              <h2 class="fichamascota">Veterinario de cabecera: <?php echo $data[$id]['veterinariocabecera']; ?></h2>
              <h2 class="fichamascota">Informacion adicional: <?php echo $data[$id]['informacionadicional']; ?></h2>
              <div class="sensores">
                <h2 class="fichamascota__sensor">Nivel Bebedero:</br><iframe src="bebedero.php" width="100" height="50"></iframe></h2>
                <h2 class="fichamascota__sensor">Collar:</br><iframe src="infrarojo.php" width="100" height="50"></iframe></h2>
                <h2 class="fichamascota__sensor">Ultrasonico:</br><iframe src="ultrasonico.php" width="100" height="50"></iframe></h2>
                <h2 class="fichamascota__sensor">Comedero:</br><iframe src="comedero.php" width="100" height="50"></iframe></h2>
              </div>
              <div>
                <form method="post" action="dashboard.php">
                    <!-- Botón para establecer el valor a 1 -->
                    <button type="submit" class="menu__button" name="comederoval" value="1">Abrir compuerta</button>
                    <!-- Botón para establecer el valor a 0 -->
                    <button type="submit" class="menu__button" name="comederoval" value="0">Cerrar compuerta</button>
                </form>
              </div>
            </div>
          </div>
          <div class="camaras">
            <h2 class="fichamascota">Camara 1</h2>
            <img src="./uploads/camara1/fotocamara1.jpg" class="imagencamara" alt="Imagen de camara1">
            <h2 class="fichamascota">Camara 2</h2>
            <img src="./uploads/camara2/fotocamara2.jpg" class="imagencamara" alt="Imagen de camara2">
          </div>

        </div>
    </div>
</body>
</html>
