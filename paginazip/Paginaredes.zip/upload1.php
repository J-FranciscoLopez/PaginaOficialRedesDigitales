<?php
// Este script maneja la recepción de imágenes enviadas mediante método POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtiene el contenido de la imagen desde el cuerpo de la solicitud POST
    $image = file_get_contents('php://input');
    // Especifica la ruta del directorio donde se guardarán las imágenes
    // Asegúrate de que este directorio existe y tiene los permisos adecuados
    $uploadDir = 'uploads/camara1/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true); // Intenta crear el directorio si no existe
    }

    // Borra todas las imágenes existentes en el directorio antes de guardar la nueva imagen
    $files = glob($uploadDir . '*'); // Obtiene todos los archivos en el directorio
    foreach ($files as $file) {
        if (is_file($file)) {
            unlink($file); // Elimina el archivo
        }
    }

    // Asigna un nombre fijo al archivo para guardar la imagen
    $filename = $uploadDir . 'fotocamara1.jpg';
    // Guarda la imagen en el archivo especificado
    file_put_contents($filename, $image);
    echo "Archivo guardado: " . $filename;
} else {
    echo "Método no permitido. Solo se aceptan solicitudes POST.";
}
?>
