<?php

    if(!file_exists("datosservo2.txt")){
        file_put_contents("datosservo2.txt", "0\r\n");
    }

    // Maneja las solicitudes POST para cambiar el valor
    if(isset($_POST['comederoval'])){
        $TEXTO = $_POST['comederoval'] . "\r\n";
        file_put_contents("datosservo2.txt", $TEXTO);
    }

    $ARCHIVO = file_get_contents("datosservo2.txt");
    $pos = strpos($ARCHIVO, "\r\n");
    $VAR1 = substr($ARCHIVO, 0, $pos);
    echo $VAR1;  // Solo devolver VAR1

?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="refresh" content="1">
    </head>

    <body>
        <p><?php echo $VAR1 ?></p>
    </body>
</html>