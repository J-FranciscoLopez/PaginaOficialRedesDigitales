<?php
include("./php/includes/config.php");
include("./php/includes/firebaseRDB.php");

// Obtener el email del dueño de la mascota desde la URL
$emailduenoperro = isset($_GET['emailduenoperro']) ? $_GET['emailduenoperro'] : "";
// Verificar si se proporcionó un email válido
if (empty($emailduenoperro)){
  exit;
}

$rdb = new firebaseRDB($databaseURL);
$retrieve = $rdb->retrieve("/mascota", "emaildueno", "EQUAL", $emailduenoperro);
$data = json_decode($retrieve, 1);

if(count($data) == 0){
  header("location: signupmascota.php");
  exit;
}else {
  $id = array_keys($data)[0];
}

$retrieve2 = $rdb->retrieve("/mascotafoto", "emaildueno", "EQUAL", $emailduenoperro);
$data2 = json_decode($retrieve2, 1);

if(count($data2) == 0){
  header("location: signupfotomascota.php");
  exit;
}else {
  $id2 = array_keys($data2)[0];
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
</head>

<body>
    <div class="backgrounddashboard">
        <div class="background__overlaydash">
          <div class="fichaperro">
            <div class="fichaperroizq">
              <h2 class="nombremascota"><?php echo $data[$id]['nombre']; ?></h2>
              <img src="./uploads/perritos/<?php echo $data2[$id2]['fotoUrl']; ?>" class="fotomascota" alt="Imagen de mascota">
            </div>
            <div class="fichaperroder">
              <h2 class="fichamascota">Raza: <?php echo $data[$id]['raza']; ?></h2>
              <h2 class="fichamascota">Edad: <?php echo $data[$id]['edad']; ?></h2>
              <h2 class="fichamascota">Padecimientos: <?php echo $data[$id]['padecimientos']; ?></h2>
              <h2 class="fichamascota">Tipo de Sangre: <?php echo $data[$id]['tipodesangre']; ?></h2>
              <h2 class="fichamascota">Direccion del dueño: <?php echo $data[$id]['direcciondueno']; ?></h2>
              <h2 class="fichamascota">Numero de contacto: <?php echo $data[$id]['numerocontacto']; ?></h2>
              <h2 class="fichamascota">Vacunas: <?php echo $data[$id]['vacunas']; ?></h2>
              <h2 class="fichamascota">Cirugias: <?php echo $data[$id]['cirugias']; ?></h2>
              <h2 class="fichamascota">Veterinario de cabecera: <?php echo $data[$id]['veterinariocabecera']; ?></h2>
              <h2 class="fichamascota">Informacion adicional: <?php echo $data[$id]['informacionadicional']; ?></h2>
            </div>
          </div>
        </div>
    </div>
</body>
</html>
